import logo from './logo.svg';
import './App.css';
import SunEdit from './AppComponent/SunEdit';

function App() {

  return (
    <div className="App">
      <SunEdit
       />
    </div>
  );
}

export default App;
